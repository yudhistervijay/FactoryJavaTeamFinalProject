package com.factory.appraisal.vehiclesearchapp.services.crudServices;
//Author:Rupesh khade,yogesh,kalyan,vijay
import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.PageInfo;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.*;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.repository.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.apache.commons.io.FilenameUtils;
import java.io.File;
import org.springframework.http.HttpHeaders;

import java.io.IOException;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@Service
public class EAppraiseVehicleServiceImpl implements EAppraiseVehicleService {
    @Autowired
    EAppraiseVehicleRepo eAppraiseVehicleRepo;
    @Autowired
    EConfigurationCodesRepo eConfigurationCodesRepo;
    @Autowired
    EAppraisalTestDriveStatusRepo eAppraisalTestDriveStatusRepo;
    @Autowired
    EUserRegistrationRepo eUserRegistrationRepo;
    @Autowired
    EDealerRegistrationRepo eDealerRegistrationRepo;
    @Autowired
    private ESignDetRepo eSignDetRepo;
    @Autowired
    private AppraisalVehicleMapper appraisalVehicleMapper;
    @Autowired
    private DealerRegistrationMapper dealerRegistrationMapper;
    @Autowired
    private UserRegistrationMapper userRegistrationMapper;
    @Autowired
    private AppraisalTestDrivingStatusMapper appraisalTestDrivingStatusMapper;
    @Autowired
    private AppraisalVehicleAcConditionMapper acConditionMapper;
    @Autowired
    private AppraisalVehicleOilConditionMapper oilConditionMapper;
    @Autowired
    private AppraisalVehicleInteriorConditionMapper interiorConditionMapper;
    @Autowired
    private AppraisalVehicleStereoStatusMapper stereoStatusMapper;
    @Autowired
    private AppraisalVehicleTireConditionMapper appraisalVehicleTireConditionMapper;
    @Autowired
    private VehicleDrivingWarnLightStatusMapper warnLightStatusMapper;
    @Autowired
    private ConfigCodesMapper configCodesMapper;
    @Autowired
    private SignDetMapper signDetMapper;

    @Override
    public Object[]  GetAppraisals(Integer pageNumber) {

        Pageable pageable = PageRequest.of(pageNumber, 10,Sort.by("createdOn").descending());
        Page<EAppraiseVehicle> pageResult = eAppraiseVehicleRepo.findAllByValidIsTrueOrderByCreatedOnDesc(pageable);

        List<EAppraiseVehicle>apv = pageResult.toList();


        List<AppraiseVehicle> appraiseVehicleDtos= appraisalVehicleMapper.modelsToDtos(apv);

        ArrayList<EAppraiseVehicle> al1= new ArrayList<>(apv);
        ArrayList<AppraiseVehicle>al2= new ArrayList<>(appraiseVehicleDtos);
        for(int i=0;i<al1.size();i++){
            al2.get(i).setDealer(dealerRegistrationMapper.modeltoDto(al1.get(i).getDealer()));
            al2.get(i).setUser(userRegistrationMapper.modelToDto(al1.get(i).getUser()));
            al2.get(i).setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus()));
            al2.get(i).getUser().setRoleConfig(configCodesMapper.modelToDto(al1.get(i).getUser().getRoleConfig()));
            al2.get(i).setSignDet(signDetMapper.modelToDto(al1.get(i).getSignDet()));
            al2.get(i).getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));
            al2.get(i).getAppraisalTestDriveStatus().setAppraisalVehicleInteriorCondition(interiorConditionMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition()));
            al2.get(i).getAppraisalTestDriveStatus().setAppraisalVehicleOilCondition(oilConditionMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition()));
            al2.get(i).getAppraisalTestDriveStatus().setAppraisalVehicleStereoStatus(stereoStatusMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus()));
            al2.get(i).getAppraisalTestDriveStatus().setAppraisalVehicleTireCondition(appraisalVehicleTireConditionMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition()));
            al2.get(i).getAppraisalTestDriveStatus().setVehicleDrivingWarnLightStatus(warnLightStatusMapper.modelToDto(al1.get(i).getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus()));

        }

        List<AppraiseVehicle> appraiseVehicleDtos1=al2;
        PageInfo pageInfo=new PageInfo();
        pageInfo.setTotalPages(al1.size()/10);
        Object[] obj=new Object[]{appraiseVehicleDtos1,pageInfo};

        return obj;
    }

    private final String FOLDER_PATH="C://myfile/";
    @Override
    public AppraiseVehicle addAppraiseVehicle(AppraiseVehicle appraiseVehicle, MultipartFile rightImage) throws IOException {


       EAppraiseVehicle eAppraiseVehicle= appraisalVehicleMapper.dtoToModel(appraiseVehicle);

        String extension = FilenameUtils.getExtension(rightImage.getOriginalFilename());
        String filename = UUID.randomUUID().toString() +"."+ extension;
        Path filePath = Paths.get(FOLDER_PATH + filename);


        Files.write(filePath, rightImage.getBytes()); //sending to folder

        eAppraiseVehicle.getAppraisalTestDriveStatus().setRearRightImage(filename);      //setting to object


        eAppraiseVehicle.getDealer().setConfigCodes(eAppraiseVehicle.getUser().getRoleConfig());
        eAppraiseVehicle.getUser().setRoleConfig(eAppraiseVehicle.getUser().getRoleConfig());

        eAppraiseVehicle.getUser().setDealer(eAppraiseVehicle.getDealer());
        eAppraiseVehicle.setUser(eAppraiseVehicle.getUser());
        eAppraiseVehicle.setDealer(eAppraiseVehicle.getDealer());
        eAppraiseVehicle.setAppraisalTestDriveStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalRef(eAppraiseVehicle);


        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition());
        eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());

        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalVehicleInteriorCondition(eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition());
        eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());

        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalVehicleOilCondition(eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition());
        eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());

        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalVehicleStereoStatus(eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());

        eAppraiseVehicle.getAppraisalTestDriveStatus().setAppraisalVehicleTireCondition(eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition());
        eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());

        eAppraiseVehicle.getAppraisalTestDriveStatus().setVehicleDrivingWarnLightStatus(eAppraiseVehicle.getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus());
        eAppraiseVehicle.getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus().setVehicleStatus(eAppraiseVehicle.getAppraisalTestDriveStatus());


        eAppraiseVehicle.getSignDet().setAppraisalReference(eAppraiseVehicle);
        eAppraiseVehicle.setSignDet(eAppraiseVehicle.getSignDet());

        eAppraiseVehicle.getUser().getRoleConfig().setCreatedOn(new Date());
      //  eAppraiseVehicle.getUser().getRoleConfig().setModifiedOn(new Date());
        eAppraiseVehicle.getDealer().setCreatedOn(new Date());
       // eAppraiseVehicle.getDealer().setModifiedOn(new Date());

        eAppraiseVehicle.getUser().setCreatedOn(new Date());
       // eAppraiseVehicle.getUser().setModifiedOn(new Date());
        eAppraiseVehicle.setCreatedOn(new Date());
        //eAppraiseVehicle.setModifiedOn(new Date());
        eAppraiseVehicle.getAppraisalTestDriveStatus().setCreatedOn(new Date());

                eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().setCreatedOn(new Date());
                eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition().setCreatedOn(new Date());
                eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition().setCreatedOn(new Date());
                eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus().setCreatedOn(new Date());
                eAppraiseVehicle.getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition().setCreatedOn(new Date());
                eAppraiseVehicle.getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus().setCreatedOn(new Date());

        eConfigurationCodesRepo.save(eAppraiseVehicle.getUser().getRoleConfig());//1
        eDealerRegistrationRepo.save(eAppraiseVehicle.getDealer());//2
        eUserRegistrationRepo.save(eAppraiseVehicle.getUser());//3


        EAppraiseVehicle eAppraiseVehicle1=eAppraiseVehicleRepo.save(eAppraiseVehicle);//4
      // eAppraisalTestDriveStatusRepo.save(eAppraiseVehicle.getAppraisalTestDriveStatus());//5


       return appraisalVehicleMapper.modelToDto(eAppraiseVehicle);

    }
    @Override
    public ResponseEntity< byte[]> findByVinNumber(String vinNum) throws IOException {
        EAppraiseVehicle apv = eAppraiseVehicleRepo.findByVinNumberAndValidIsTrue(vinNum);
        if(apv!=null) {

            AppraiseVehicle appraiseVehicleDto = appraisalVehicleMapper.modelToDto(apv);

            appraiseVehicleDto.setDealer(dealerRegistrationMapper.modeltoDto(apv.getDealer()));
            appraiseVehicleDto.setUser(userRegistrationMapper.modelToDto(apv.getUser()));
            appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(apv.getAppraisalTestDriveStatus()));
            appraiseVehicleDto.getUser().setRoleConfig(configCodesMapper.modelToDto(apv.getUser().getRoleConfig()));
            appraiseVehicleDto.setSignDet(signDetMapper.modelToDto(apv.getSignDet()));

            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.modelToDto(apv.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleInteriorCondition(interiorConditionMapper.modelToDto(apv.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleOilCondition(oilConditionMapper.modelToDto(apv.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleStereoStatus(stereoStatusMapper.modelToDto(apv.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setVehicleDrivingWarnLightStatus(warnLightStatusMapper.modelToDto(apv.getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleTireCondition(appraisalVehicleTireConditionMapper.modelToDto(apv.getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition()));
           //finding image
            String filePath=FOLDER_PATH+appraiseVehicleDto.getAppraisalTestDriveStatus().getRearRightImage();
            byte[] image= Files.readAllBytes(new File(filePath).toPath());

            //loading object and file to map
            Map<String, Object> data = new HashMap<>();
            data.put("object", appraiseVehicleDto);
            data.put("file", image);
//             you can add more images here        data.put("file2",image2);

            // Return the map as JSON

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            return new ResponseEntity<>(new ObjectMapper().writeValueAsBytes(data), headers, HttpStatus.OK);


        }
        else throw new RuntimeException("Did not find AppraisalVehicle of  - " + vinNum);

    }

    @Override
    public AppraiseVehicle updateAppraisalVehicle(AppraiseVehicle eAppraiseVehicledto, MultipartFile rightImage) throws IOException{


        EAppraiseVehicle vehicle = eAppraiseVehicleRepo.findByVinNumber(eAppraiseVehicledto.getVinNumber());
        if(vehicle!=null){

            if(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalRef()==null){

                eAppraiseVehicledto.getAppraisalTestDriveStatus().setAppraisalRef(appraisalVehicleMapper.modelToDto(vehicle));

            }

            if(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().getVehicleStatus()==null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }

            if (eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition().getVehicleStatus() == null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }
            if (eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition().getVehicleStatus() == null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }
            if (eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus().getVehicleStatus() == null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }
            if(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition().getVehicleStatus()==null){
                eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }
            if(eAppraiseVehicledto.getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus().getVehicleStatus()==null) {

                eAppraiseVehicledto.getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus().setVehicleStatus(eAppraiseVehicledto.getAppraisalTestDriveStatus());
            }




            //add new file
            String extension = FilenameUtils.getExtension(rightImage.getOriginalFilename());
            String filename = UUID.randomUUID().toString() +"."+ extension;
            Path filePath = Paths.get(FOLDER_PATH + filename);


            Files.write(filePath, rightImage.getBytes()); //sending to folder

            //delete old file
            String old = FOLDER_PATH + vehicle.getAppraisalTestDriveStatus().getRearRightImage();
            Path filePathOld = Paths.get(old);
            Files.delete(filePathOld);


            eAppraiseVehicledto.getAppraisalTestDriveStatus().setRearRightImage(filename);      //setting to object


            vehicle.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus()));
            vehicle.getAppraisalTestDriveStatus().setModifiedOn(new Date());

           vehicle.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));
           vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition().setModifiedOn(new Date());

            vehicle.getAppraisalTestDriveStatus().setAppraisalVehicleInteriorCondition(interiorConditionMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition()));
            vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition().setModifiedOn(new Date());

            vehicle.getAppraisalTestDriveStatus().setAppraisalVehicleOilCondition(oilConditionMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition()));
            vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition().setModifiedOn(new Date());

            vehicle.getAppraisalTestDriveStatus().setAppraisalVehicleStereoStatus(stereoStatusMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus()));
            vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus().setModifiedOn(new Date());

            vehicle.getAppraisalTestDriveStatus().setAppraisalVehicleTireCondition(appraisalVehicleTireConditionMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition()));
            vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition().setModifiedOn(new Date());

            vehicle.getAppraisalTestDriveStatus().setVehicleDrivingWarnLightStatus(warnLightStatusMapper.dtoToModel(eAppraiseVehicledto.getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus()));
            vehicle.getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus().setModifiedOn(new Date());

            vehicle.setModifiedOn(new Date());
            eAppraiseVehicleRepo.save(vehicle);

             AppraiseVehicle appraiseVehicleDto= appraisalVehicleMapper.modelToDto(vehicle);

            appraiseVehicleDto.setAppraisalTestDriveStatus(appraisalTestDrivingStatusMapper.modelToDto(vehicle.getAppraisalTestDriveStatus()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleAcCondition(acConditionMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleAcCondition()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleInteriorCondition(interiorConditionMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleInteriorCondition()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleOilCondition(oilConditionMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleOilCondition()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleStereoStatus(stereoStatusMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleStereoStatus()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setAppraisalVehicleTireCondition(appraisalVehicleTireConditionMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getAppraisalVehicleTireCondition()));
            appraiseVehicleDto.getAppraisalTestDriveStatus().setVehicleDrivingWarnLightStatus(warnLightStatusMapper.modelToDto(vehicle.getAppraisalTestDriveStatus().getVehicleDrivingWarnLightStatus()));

            return appraiseVehicleDto;

        }

       else throw new RuntimeException("Did not find AppraisalVehicle of "+eAppraiseVehicledto.getVinNumber() );

    }

    @Override
    public String deleteAppraisalVehicle(String vinNum) {
        EAppraiseVehicle byVinNumber = eAppraiseVehicleRepo.findByVinNumber(vinNum);

        if(byVinNumber!=null && byVinNumber.getValid()==true) {
            byVinNumber.setValid(false);
            eAppraiseVehicleRepo.save(byVinNumber);

            return "deleted";
        }
        else
        throw new RuntimeException("Did not find AppraisalVehicle of  - " + vinNum);
    }
}
