package com.factory.appraisal.vehiclesearchapp.services.crudServices;


import com.factory.appraisal.vehiclesearchapp.Author;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.ConfigurationCodes;

import java.util.List;
@Author("Yogesh Kumar V")
public interface EConfigurationCodesService {
    public ConfigurationCodes addConfigCode(ConfigurationCodes configurationCodes);
    List<ConfigurationCodes> GetConfigCodes(Integer pageNo, Integer pageSize);
    ConfigurationCodes updateConfigCodes(long codeId,ConfigurationCodes configurationCodes);
    String deleteConfigCodes(long codeId);

}
