package com.factory.appraisal.vehiclesearchapp.services.crudServices;
import com.factory.appraisal.vehiclesearchapp.Author;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.ConfigurationCodes;
import com.factory.appraisal.vehiclesearchapp.persistence.mapper.ConfigCodesMapper;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EConfigurationCodes;
import com.factory.appraisal.vehiclesearchapp.repository.EConfigurationCodesRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Author("Yogesh Kumar V")
@Service
public class EConfigurationCodesServiceImpl implements EConfigurationCodesService{
    @Autowired
    private EConfigurationCodesRepo eConfigurationCodesRepo;
    @Autowired
    private ConfigCodesMapper configCodesMapper;

    @Override
    public ConfigurationCodes addConfigCode(ConfigurationCodes configurationCodes) {
        EConfigurationCodes eConfigurationCodes=configCodesMapper.dtoToModel(configurationCodes);
        eConfigurationCodes.setCreatedOn(new Date());
        return configCodesMapper.modelToDto(eConfigurationCodesRepo.save(eConfigurationCodes));
    }

    @Override
    public List<ConfigurationCodes> GetConfigCodes(Integer pageNo, Integer pageSize) {
        Pageable pageable = PageRequest.of(pageNo, pageSize, Sort.by("createdOn").descending());
        Page<EConfigurationCodes>pageResult=eConfigurationCodesRepo.findAllByValidIsTrueOrderByCreatedOnDesc(pageable);
        List<EConfigurationCodes>eConfigurationCodes = pageResult.toList();
        List<ConfigurationCodes>configurationCodes=configCodesMapper.modelsToDtos(eConfigurationCodes);
        return configurationCodes;
    }

    @Override
    public ConfigurationCodes updateConfigCodes(long codeId, ConfigurationCodes configurationCodes) {
        EConfigurationCodes model = configCodesMapper.dtoToModel(configurationCodes);
        EConfigurationCodes eConfigurationCodes=eConfigurationCodesRepo.findById(codeId).get();
        if (eConfigurationCodes!=null){
            if (configurationCodes.getValid()!=false){
                if (configurationCodes.getCodeType()!=null){
                    eConfigurationCodes.setCodeType(configurationCodes.getCodeType());
                }
                if (configurationCodes.getLongCode()!=null){
                    eConfigurationCodes.setLongCode(configurationCodes.getLongCode());
                }
                if (configurationCodes.getShortCode()!=null){
                    eConfigurationCodes.setShortCode(configurationCodes.getShortCode());
                }
                if (configurationCodes.getShortDescription()!=null) {
                    eConfigurationCodes.setShortDescription(configurationCodes.getShortDescription());
                }


                eConfigurationCodes.setModifiedBy(configurationCodes.getModifiedBy());
                eConfigurationCodes.setModifiedOn(new Date());
            }
            return configCodesMapper.modelToDto(eConfigurationCodes);
        }
        else throw new RuntimeException("Did not find ConfigCodes of "+codeId);
    }

    @Override
    public String deleteConfigCodes(long codeId) {
        EConfigurationCodes eConfigurationCodes = eConfigurationCodesRepo.findById(codeId).get();
        if(eConfigurationCodes!=null){
            eConfigurationCodes.setValid(false);
            eConfigurationCodesRepo.save(eConfigurationCodes);
            return "deleted";
        }
        throw new RuntimeException("ConfigCodes not found with codeId : " + codeId);
    }

}
