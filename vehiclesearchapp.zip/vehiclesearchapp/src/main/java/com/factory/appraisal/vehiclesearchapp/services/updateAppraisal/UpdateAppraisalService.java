package com.factory.appraisal.vehiclesearchapp.services.updateAppraisal;

public interface UpdateAppraisalService {
}
