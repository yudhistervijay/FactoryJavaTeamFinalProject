package com.factory.appraisal.vehiclesearchapp.persistence.mapper;

import com.factory.appraisal.vehiclesearchapp.persistence.dto.TransactionEntity;
import com.factory.appraisal.vehiclesearchapp.persistence.model.ETransactionEntity;
import org.mapstruct.*;


@Mapper(componentModel = "spring")
public interface TransactionEntityMapper {

    @Mapping(target = "createdOn",dateFormat = "MM/dd/yyyy HH:mm:ss")
    @Mapping(target = "modifiedOn",dateFormat = "MM/dd/yyyy HH:mm:ss")
    ETransactionEntity dtoToModel(TransactionEntity transaction);

@InheritInverseConfiguration
    TransactionEntity modelToDto(ETransactionEntity eTransactionEntity);


}
