package com.factory.appraisal.vehiclesearchapp.services.auditService;

import java.util.ArrayList;
import java.util.Map;

public interface AuditAppraisalTestDriveStatusService {
    ArrayList<Map<String,Object>> getAuditedData(String field);
}
