package com.factory.appraisal.vehiclesearchapp.services.getAppraisals;

import com.factory.appraisal.vehiclesearchapp.Constants;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.repository.EAppraiseVehicleRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Optional;

@Service
public class GetImagesServiceImpl implements GetImagesService{
    @Autowired
    private EAppraiseVehicleRepo vehicleRepo;

    public byte[] downloadImageFromFileSystem(Long appraisalReferenceId) throws IOException {
        EAppraiseVehicle  vehicle= vehicleRepo.findById(appraisalReferenceId).orElse(null);
        if(vehicle!=null){


            String filePath= Constants.FOLDER_PATH +vehicle.getAppraisalTestDriveStatus().getRearRightImage();
            byte[] images = Files.readAllBytes(new File(filePath).toPath());//**************************Reading from folder
            return images;

        }
        else throw new RuntimeException("ImageNot found for given Id");



    }
}
