package com.factory.appraisal.vehiclesearchapp.controller;

import com.factory.appraisal.vehiclesearchapp.Author;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.ConfigurationCodes;
import com.factory.appraisal.vehiclesearchapp.services.crudServices.EConfigurationCodesService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Author("Yogesh Kumar V")
@RestController
@RequestMapping("/congifcodes")
@Api(value = "ConfigCodesController",description = "Operations in **ConfigCodesController**")
public class ConfigCodesController {
    @Autowired
    private EConfigurationCodesService configurationCodesService;

    @ApiOperation(value = "Add Config Codes in Database")
    @PostMapping("/post")
    public ResponseEntity<ConfigurationCodes> postConfigurationCodes(@RequestBody @Valid ConfigurationCodes configurationCodes){
        return new ResponseEntity<>(configurationCodesService.addConfigCode(configurationCodes),
                HttpStatus.OK
        );
    }
    @GetMapping("/showall/{pageNumber}/{pageSize}")
    public ResponseEntity<List<ConfigurationCodes>> showAllConfigurationCodes(@PathVariable Integer pageNumber,@PathVariable Integer pageSize){
        return new ResponseEntity<>(configurationCodesService.GetConfigCodes(pageNumber,pageSize),
                HttpStatus.OK
        );
    }
    @PutMapping("/update/{codeId}")
    public ResponseEntity<ConfigurationCodes> changeEConfigurationCodes(@PathVariable long codeId, @RequestBody @Valid ConfigurationCodes configurationCodes){
        return new ResponseEntity<>(configurationCodesService.updateConfigCodes(codeId,configurationCodes),
                HttpStatus.ACCEPTED
        );
    }
    @DeleteMapping("/delete/{codeId}")
    public ResponseEntity<String> deleteEConfigurationCode(@PathVariable long codeId){
        return new ResponseEntity<>(configurationCodesService.deleteConfigCodes(codeId),
                HttpStatus.OK
        );
    }
}
