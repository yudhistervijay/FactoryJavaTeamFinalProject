package com.factory.appraisal.vehiclesearchapp.services.auditService;

import com.factory.appraisal.vehiclesearchapp.repository.EAppraisalTestDriveStatusRepo;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public interface AuditServiceOnEAppraisalDriveStatus {

    List<Object[]> getAuditData();

}
