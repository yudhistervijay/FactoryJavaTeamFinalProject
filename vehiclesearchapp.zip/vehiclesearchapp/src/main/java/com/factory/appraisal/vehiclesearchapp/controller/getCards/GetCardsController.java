package com.factory.appraisal.vehiclesearchapp.controller.getCards;
//Author: Rupesh Khade
import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.services.getAppraisals.GetAppraisalCardsImpl;
import com.factory.appraisal.vehiclesearchapp.services.getAppraisals.GetImagesServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/api/appraisal")
public class GetCardsController {

    @Autowired
    private GetAppraisalCardsImpl cardService;
    @Autowired
    private GetImagesServiceImpl imagesService;

    @GetMapping("/getAppraisals/{pageNumber}")
    public ResponseEntity<?> getAppraisals(@PathVariable Integer pageNumber){
        try {
            List<AppraiseVehicle> apv = cardService.findAllCards(pageNumber);


            return new ResponseEntity<>(apv, HttpStatus.ACCEPTED);
        }catch (IllegalArgumentException e) {

            String message = "Invalid page number. Page number and page size must be positive integers.";
            return ResponseEntity.badRequest().body(Collections.singletonMap("message", message));
        } catch (Exception e) {
            // handle other exceptions
            String message = "An error occurred while retrieving appraisals.";
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Collections.singletonMap("message", message));
        }

    }

    @GetMapping("/getCard/{vinNo}")
    public ResponseEntity<AppraiseVehicle> getCard(@PathVariable String vinNo){

        return new ResponseEntity<>(cardService.findByVinNumber(vinNo), HttpStatus.ACCEPTED) ;

    }
    @GetMapping("/getRRImage/{appraisalReferenceId}")
    public ResponseEntity<?> downloadImageFromFileSystem(@PathVariable Long appraisalReferenceId) throws IOException {
        byte[] bytes = imagesService.downloadImageFromFileSystem(appraisalReferenceId);
        return ResponseEntity.status(HttpStatus.OK)
                .contentType(MediaType.valueOf("image/jpeg"))
                .body(bytes);

    }

}
