package com.factory.appraisal.vehiclesearchapp.services.crudServices;

import com.factory.appraisal.vehiclesearchapp.Author;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.DealerRegistration;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
@Author("Yogesh Kumar V")
public interface EDealerRegistrationService {
    List<DealerRegistration>getDealerRegistrations(Integer pageNumber, Integer pageSize);
    DealerRegistration addDealerRegistration(DealerRegistration dealerRegistration, MultipartFile profilePicture) throws IOException;
    DealerRegistration updateDealerRegistration(long dealerId,DealerRegistration dealerRegistration,MultipartFile profilePicture) throws IOException;
    String deleteDealerRegistration(long dealerId);

}
