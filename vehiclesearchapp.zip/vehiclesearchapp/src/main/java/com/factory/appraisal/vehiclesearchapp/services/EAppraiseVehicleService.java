package com.factory.appraisal.vehiclesearchapp.services;

import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EAppraiseVehicle;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Date;
import java.util.List;

public interface EAppraiseVehicleService {

    List<AppraiseVehicle> GetAppraisals(Integer pageNo, Integer pageSize);
    AppraiseVehicle addAppraiseVehicle(AppraiseVehicle eAppraiseVehicle, MultipartFile rightImage) throws IOException;
   // AppraiseVehicle findByVinNumber(String vinNum)throws IOException;
   ResponseEntity<byte[]> findByVinNumber(String vinNum)throws IOException;
    AppraiseVehicle updateAppraisalVehicle(AppraiseVehicle appraiseVehicle, MultipartFile rightImage) throws IOException;
    String deleteAppraisalVehicle(String vinNum);




}
