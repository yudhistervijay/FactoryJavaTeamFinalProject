package com.factory.appraisal.vehiclesearchapp.services.getAppraisals;

import com.factory.appraisal.vehiclesearchapp.persistence.dto.AppraiseVehicle;


import java.util.List;


public interface GetAppraisalsCard {

    AppraiseVehicle findByVinNumber(String vinNo);
   List<AppraiseVehicle> findAllCards(Integer pageNumber);
}
