package com.factory.appraisal.vehiclesearchapp;

public class Constants {
    public static final String FOLDER_PATH="C://myfile/";
    public static final String ImagesToUI_PATH="http://192.168.137.85:8080/api/appraisal/getRRImage/";

}
