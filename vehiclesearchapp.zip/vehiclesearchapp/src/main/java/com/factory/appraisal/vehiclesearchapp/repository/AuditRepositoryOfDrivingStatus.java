package com.factory.appraisal.vehiclesearchapp.repository;
//Author :Rupesh Khade
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Repository
public class AuditRepositoryOfDrivingStatus {

    @PersistenceContext
    private EntityManager entityManager;

    @Transactional(readOnly = true)
    public  List<Object[]>  executeSqlQuery(String field,Long id,Integer offset) {
        String sql = "SELECT b.veh_status_id,b.rev,b.revtype,Lag(b."+field+", 1) " +
                "OVER (PARTITION BY b.veh_status_id ORDER BY rev.modified_on) " +
                "AS old_value_of_"+field+",b."+field+" AS new_value_of_"+field+",rev.modified_by,rev.modified_on " +
                "FROM factory_aud.apr_test_dr_status_aud AS b,factory_db.apr_test_dr_status as rev where b.veh_status_id= "+id+" LIMIT 10 OFFSET "+offset+"";

        List<Object[]> resultList = entityManager.createNativeQuery(sql).getResultList();
        return resultList;
    }
}