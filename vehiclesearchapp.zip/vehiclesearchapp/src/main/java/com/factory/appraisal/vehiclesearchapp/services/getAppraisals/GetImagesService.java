package com.factory.appraisal.vehiclesearchapp.services.getAppraisals;

import java.io.IOException;

public interface GetImagesService {
    public byte[] downloadImageFromFileSystem(Long appraisalReferenceId) throws IOException;
}
