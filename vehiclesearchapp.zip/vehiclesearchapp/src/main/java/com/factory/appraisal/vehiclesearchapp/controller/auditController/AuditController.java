package com.factory.appraisal.vehiclesearchapp.controller.auditController;
//Author :Rupesh khade

import com.factory.appraisal.vehiclesearchapp.services.auditService.AuditAppraisalTestDriveStatusServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/audit")
public class AuditController {

    @Autowired
    private AuditAppraisalTestDriveStatusServiceImpl service;

    @GetMapping("/getAuditOfAppraisalTestDriveStatus/{field}")
    public ResponseEntity<List<Map<String,Object>> >getAudit(@PathVariable String field){
        ArrayList<Map<String,Object>> auditRecords = service.getAuditedData(field);
        return new ResponseEntity<>((List<Map<String, Object>>) auditRecords, HttpStatus.ACCEPTED);
    }





}
