package com.factory.appraisal.vehiclesearchapp.services.auditService;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.Date;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AuditEntry {
    private Integer revision;
    private Object oldValue;
    private Object newValue;
    private String modifiedBy;
    private LocalDateTime modifiedDate;


}
