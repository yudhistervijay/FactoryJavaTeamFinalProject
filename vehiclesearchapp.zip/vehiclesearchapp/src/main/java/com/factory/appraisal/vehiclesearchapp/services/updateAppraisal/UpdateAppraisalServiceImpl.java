package com.factory.appraisal.vehiclesearchapp.services.updateAppraisal;

public class UpdateAppraisalServiceImpl implements UpdateAppraisalService{
}
