package com.factory.appraisal.vehiclesearchapp.controller;

import com.factory.appraisal.vehiclesearchapp.Author;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.DealerRegistration;
import com.factory.appraisal.vehiclesearchapp.services.crudServices.EDealerRegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.validation.Valid;
import java.io.IOException;
import java.util.List;

@Author("Yogesh Kumar V")
@RestController
@RequestMapping("/dealerregistration")
public class DealerRegistrationController {
    @Autowired
    private EDealerRegistrationService eDealerRegistrationService;
    @PostMapping("/post")
    public ResponseEntity<DealerRegistration>postDealerRegistration
            (@RequestPart("data") @Valid DealerRegistration dealerRegistration, @RequestPart("profilePicture")MultipartFile profilePicture) throws IOException {
        return new ResponseEntity<>(eDealerRegistrationService.addDealerRegistration(dealerRegistration,profilePicture),
                HttpStatus.OK
        );
    }
    @GetMapping("/showall/{pageNumber}/{pageSize}")
    public ResponseEntity<List<DealerRegistration>>showAllDealerRegistration(@PathVariable Integer pageNumber,@PathVariable Integer pageSize){
        return new ResponseEntity<>(eDealerRegistrationService.getDealerRegistrations(pageNumber,pageSize),
                HttpStatus.OK
        );
    }
    @PutMapping("/upgrade/{dealerId}")
    public ResponseEntity<DealerRegistration>changeDealerRegistration
            (@PathVariable long dealerId, @RequestPart("data") @Valid DealerRegistration dealerRegistration, @RequestPart("profilePicture") MultipartFile profilePicture) throws IOException {
        return new ResponseEntity<>(eDealerRegistrationService.updateDealerRegistration(dealerId,dealerRegistration,profilePicture),
                HttpStatus.ACCEPTED
        );
    }
    @DeleteMapping("/delete/{dealerId}")
    public ResponseEntity<String> deleteDealerRegistration(@PathVariable long dealerId){
        return new ResponseEntity<>(eDealerRegistrationService.deleteDealerRegistration(dealerId),
                HttpStatus.OK
        );
    }


}
