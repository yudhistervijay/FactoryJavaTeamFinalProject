package com.factory.appraisal.vehiclesearchapp.persistence.mapper;
//@author:Rupesh Khade


import com.factory.appraisal.vehiclesearchapp.persistence.dto.ConfigurationCodes;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.DealerRegistration;
import com.factory.appraisal.vehiclesearchapp.persistence.dto.UserRegistration;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EConfigurationCodes;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EDealerRegistration;
import com.factory.appraisal.vehiclesearchapp.persistence.model.EUserRegistration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;

@Mapper(componentModel = "spring")
public interface UserRegistrationMapper {

    DealerRegistrationMapper INSTANCE1 = Mappers.getMapper(DealerRegistrationMapper.class);
    ConfigCodesMapper INSTANCE2 = Mappers.getMapper(ConfigCodesMapper.class);
    @Mapping(target = "roleConfig",ignore = true)
    @Mapping(target = "dealer",ignore = true)
    @Mapping(target = "createdOn",dateFormat = "MM/dd/yyyy HH:mm:ss")
    @Mapping(target = "modifiedOn",dateFormat = "MM/dd/yyyy HH:mm:ss")
    UserRegistration modelToDto( EUserRegistration eUserRegistration);
    @Mapping(target = "roleConfig",expression = "java(mapConfigCodes(userRegistration.getRoleConfig()))")
    @Mapping(target = "dealer",expression = "java(mapDealerReg(userRegistration.getDealer()))")
    @Mapping(target = "createdOn",dateFormat = "MM/dd/yyyy HH:mm:ss")
    @Mapping(target = "modifiedOn",dateFormat = "MM/dd/yyyy HH:mm:ss")
    EUserRegistration dtoToModel( UserRegistration userRegistration);
    List<UserRegistration> modelToDto(List<EUserRegistration> eUserRegistrationList);

    default EDealerRegistration mapDealerReg(DealerRegistration dealerRegistrationDto){
        return INSTANCE1.dtoToModel(dealerRegistrationDto);
    }

    default EConfigurationCodes mapConfigCodes(ConfigurationCodes configurationCodesDto){
        return INSTANCE2.dtoToModel(configurationCodesDto);
    }


}
